package br.edu.utfpr.tcp;

import java.io.*;
import java.net.*;

public class Servidor {

    public static ServerSocket servidor;
    public static Socket conexao;
    public static DataInputStream entrada;
    public static DataOutputStream saida;

    public static void main(String[] args) {

        try {

            // iniciar servico
            System.out.println("Servidor pronto!");
            servidor = new ServerSocket(4000);
            while (true) {
                conexao = servidor.accept();

                // esperar requisicoes
                entrada = new DataInputStream(conexao.getInputStream());
                saida = new DataOutputStream(conexao.getOutputStream());

                int numero = entrada.readInt();
                
                
                String resultado;
                if (numero > 0) {
                    resultado = "Maior que zero";
                } else {
                    resultado = "Menor ou igual a zero";
                }

                // responder requisicoes
                saida.writeUTF(resultado);

                // fechar conexao
                conexao.close();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }

    }

}
